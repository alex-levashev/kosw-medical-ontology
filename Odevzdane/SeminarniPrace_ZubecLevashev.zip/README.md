# KOSW Ontology
Please use Protege to open this ontology
